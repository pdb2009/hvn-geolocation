Logger = {
  /**
    * Logs the variable to the command line
    */
    log: function(variable) {
        writeln(variable);
    }
};