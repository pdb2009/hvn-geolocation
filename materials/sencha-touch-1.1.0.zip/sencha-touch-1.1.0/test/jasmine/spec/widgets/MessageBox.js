xdescribe("Ext.MessageBox", function() {
    var mb;
    
    beforeEach(function() {
        mb = new Ext.MessageBox({
            title: 'test',
            msg: 'message'
        });
    });
});